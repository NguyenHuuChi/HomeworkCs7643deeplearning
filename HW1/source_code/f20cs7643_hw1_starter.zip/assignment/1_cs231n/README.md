# Homework 1 - Part 1

Student starter code for Deep Learning HW1
